$('#menu').slicknav({
	label: '',
	duration: 1400,
	easingOpen: "easeOutBounce", //available with jQuery UI
	
});